﻿using CW_WAD.Controllers;
using CW_WAD.DAO;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace CW_WAD.DAL
{
    public class UsersDAL
    {
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["MyConStr"].ConnectionString);

        public DataSet LoadAllDataDAL()
        {
            SqlCommand com = new SqlCommand("getAllUsers", conn);
            com.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataSet dss = new DataSet();
            da.Fill(dss);
            return dss;
        }

        public void AddUserDAL(Users user)
        {
            SqlCommand com = new SqlCommand("createUser", conn);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@username", user.login);
            com.Parameters.AddWithValue("@password", user.password);
            com.Parameters.AddWithValue("@email", user.email);
            com.Parameters.AddWithValue("@phone_number", user.phone_number);
            conn.Open();
            com.ExecuteNonQuery();
            conn.Close();
        }

        public bool LoginDAL(LoginModel login)
        {
            
            SqlCommand com = new SqlCommand("login_main", conn);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@login", login.login);
            com.Parameters.AddWithValue("@password", login.password);
            com.Parameters.AddWithValue("@result", 1);

            var returnParameter = com.Parameters.Add("@result", SqlDbType.Int);
            returnParameter.Direction = ParameterDirection.ReturnValue;


            conn.Open();
            com.ExecuteNonQuery();
            conn.Close();

            var result = (int)returnParameter.Value;

            Console.WriteLine(result);

            if (result == 200)
            {
                return true;
            }
            return false;
        }

    }
}