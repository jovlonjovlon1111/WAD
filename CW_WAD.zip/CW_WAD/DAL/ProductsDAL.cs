﻿using CW_WAD.DAO;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace CW_WAD.DAL
{
    public class ProductsDAL
    {
        SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["MyConStr"].ConnectionString);

        public DataSet getProducts()
        {
            SqlCommand com = new SqlCommand("getProducts", conn);
            com.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataSet dss = new DataSet();
            da.Fill(dss);
            return dss;
        }

        public void update_product(Products product)
        {
            SqlCommand com = new SqlCommand("update_product", conn);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@id", product.id);
            com.Parameters.AddWithValue("@name", product.name);
            com.Parameters.AddWithValue("@price", product.price);
            com.Parameters.AddWithValue("@decription", product.decription);
            conn.Open();
            com.ExecuteNonQuery();
            conn.Close();
        }

        public void delete_product (int id)
        {
            SqlCommand com = new SqlCommand("delete_product", conn);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@id", id);
            conn.Open();
            com.ExecuteNonQuery();
            conn.Close();
        }

        public DataSet get_product(int id)
        {
            SqlCommand com = new SqlCommand("get_product", conn);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@id", id);
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataSet dss = new DataSet();
            da.Fill(dss);
            return dss;
        }

        public void add_product(Products product)
        {
            SqlCommand com = new SqlCommand("add_product", conn);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@name", product.name);
            com.Parameters.AddWithValue("@price", product.price);
            com.Parameters.AddWithValue("@decription", product.decription);
            conn.Open();
            com.ExecuteNonQuery();
            conn.Close();
        }
    }
}