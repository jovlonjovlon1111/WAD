﻿using CW_WAD.DAL;
using CW_WAD.DAO;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;

namespace CW_WAD.Controllers
{
    public class ProductController : Controller
    {
        ProductsDAL productsDAL = new ProductsDAL();

        // GET: Product
        public ActionResult Index()
        {
            
            return View();
        }

        public ActionResult ListView()
        {
            return View();
        }


        [System.Web.Http.HttpPost]
        [System.Web.Http.Route("PostX")]
    public JsonResult add_product([FromBody]Products products)
        {
            
            string Mes = "";

            try
            {
                productsDAL.add_product(products);
                Mes = "Successfully Saved";
            }
            catch (Exception e)
            {
                Mes = "Failed!!";
            }

            return Json(Mes, JsonRequestBehavior.AllowGet);
        }

        public JsonResult update_product(Products products)
        {

            string Mes = "";

            try
            {
                productsDAL.update_product(products);
                Mes = "Successfully Updated";
            }
            catch (Exception e)
            {
                Mes = "Failed!!";
            }

            return Json(Mes, JsonRequestBehavior.AllowGet);
        }

        public JsonResult delete_product(int id)
        {

            string Mes = "";

            try
            {
                productsDAL.delete_product(id);
                Mes = "Successfully deleted";
            }
            catch (Exception e)
            {
                Mes = "Failed!!";
            }

            return Json(Mes, JsonRequestBehavior.AllowGet);
        }

        public JsonResult get_products()
        {

            DataSet ds = productsDAL.getProducts();
            List<Products> lists = new List<Products>();
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                lists.Add(new Products
                {
                    id = Convert.ToInt32(dr["id"]),
                    name = (dr["name"].ToString()),
                    price = (Convert.ToDouble(dr["price"])),
                    decription = (dr["decription"].ToString())
                });
            }

            return Json(lists, JsonRequestBehavior.AllowGet);
        }

        public JsonResult get_product(int id)
        {

            DataSet ds = productsDAL.get_product(id);
            List<Products> lists = new List<Products>();
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                lists.Add(new Products
                {
                    id = Convert.ToInt32(dr["id"]),
                    name = (dr["name"].ToString()),
                    price = (Convert.ToDouble(dr["price"])),
                    decription = (dr["decription"].ToString())
                });
            }

            return Json(lists, JsonRequestBehavior.AllowGet);
        }
    }
}