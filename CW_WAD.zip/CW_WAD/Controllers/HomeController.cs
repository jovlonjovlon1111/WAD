﻿using CW_WAD.DAL;
using CW_WAD.DAO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace CW_WAD.Controllers
{
    public class HomeController : Controller
    {
        UsersDAL aDal = new UsersDAL();


        public ActionResult Index()
        {
            return RedirectToAction("Login");
        }


        public ActionResult Register()
        {
            Users objUserModel = new Users();
            return View(objUserModel);
        }

        [HttpPost]
        public async Task<ActionResult> Register(Users addUserDAL)
        {

            aDal.AddUserDAL(addUserDAL);
            return RedirectToAction("Login");
        }


        public ActionResult Login()
        {
            LoginModel login = new LoginModel();
            return View(login);
        }

        [HttpPost]
        public async Task<ActionResult> Login(LoginModel loginModel)
        {

            var result = aDal.LoginDAL(loginModel);
            if (result)
            {
                return RedirectToAction("Index", "Product");
            }
            else
            {
                return RedirectToAction("Register");

            }

        }


        public JsonResult LoadData()
        {
            DataSet ds = aDal.LoadAllDataDAL();
            List<Users> lists = new List<Users>();
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                lists.Add(new Users
                {
                    user_id = Convert.ToInt32(dr["user_id"]),
                    login = (dr["login"].ToString()),
                    password = (dr["password"].ToString()),
                    email = (dr["email"].ToString()),
                    phone_number = (dr["phone_number"].ToString()),
                });
            }

            return Json(lists, JsonRequestBehavior.AllowGet);
        }
    }
}