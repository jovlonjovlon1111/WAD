﻿namespace CW_WAD.Controllers
{
    public class LoginModel
    {
        public string login { get; set; }
        public string password { get; set; }
    }
}